function goBack  () {
  // Get the current URL
  var currentURL = window.location.href;

  // Check if the URL ends with www/index.html
  if (currentURL.endsWith("www/index.html")) {
    
      navigator.app.exitApp();
  
  } else {
    // If not, go back in the Cordova WebView history
    window.history.back();
  }
}