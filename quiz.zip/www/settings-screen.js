class SettingsScreen {
    constructor() {
        this.inAppBrowserRef = null;

        // Binding the methods to the class instance
        this.hide = this.hide.bind(this);
        this.open = this.open.bind(this);
        this.hide();

        
    }

    hide() {
        if (this.inAppBrowserRef) {
            this.inAppBrowserRef.close();
            this.inAppBrowserRef = null;
        }
    }

    open() {
        const url = document.createElement('a')
        url.href = "setting.html"

        this.inAppBrowserRef = cordova.InAppBrowser.open(url.href.replace('map/',''), '_blank', 'toolbar=no,location=no,fullscreen=no,zoom=no,transitionstyle=crossdissolve');
        this.inAppBrowserRef.addEventListener('message',() => {
            
            this.hide()
        })
    }
}
