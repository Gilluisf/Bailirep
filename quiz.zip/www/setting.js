const buttonAudio = new Audio("music/button.ogg")
//buttonAudio.play()
buttonAudio.volume = 0
document.querySelectorAll("#menu-screen .button-captioned").forEach(el => el.addEventListener('click', () => buttonAudio.play()))
const settingsScreen = new SettingsScreen()