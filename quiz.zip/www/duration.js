function createDurationElement(region,levelNumber,{min,max,current}){
	var htmlCode = `
	<!--div class="setting-div country-duration"-->
            <div class="centered">
                <!--img src="img/clock.png" class="img-button"-->
            </div>

        
            <button class="button large">
                <span class="left-badge button-3d">Nivel ${levelNumber}</span>
                <span class="level-name">${region}</span>
            </button>
            <div class="range">

                <div>
                    <input type="range" class="custom-range" id="music-range" min="${min}" max="${max}" value="${current}">
                </div>

                <div class="min-duration">
                    <!--span>${min} Minuto</span>
                    <span>Tempo minimo</span-->
                </div>

                <div></div>
                <div></div>

                <div class="max-duration">
                    <span>${current} Minuto</span>
                    <span><!--Tempo maximo--></span>
                </div>
            </div>
        <!--/div-->
	`

	var div = document.createElement('div')
	div.setAttribute('class','setting-div country-duration')
	div.innerHTML = htmlCode

	return div
}

var durations = [
    {
        region:'Moçambique',
        levelNumber: 1,
        min: 1,
        max: 7,
        current: localStorage.getItem('Moçambique') || 1
    },
    {
        region: 'África',
        levelNumber: 2,
        min: 1,
        max: 10,
        current: localStorage.getItem('África') || 1
    },
    {
        region: 'Mundo',
        levelNumber: 3,
        min: 1,
        max: 15,
        current: localStorage.getItem('Mundo') || 1
    },
]

durations.reverse().forEach(function(data){
    
    const {region,levelNumber,min,max,current} = data
    const element = createDurationElement(region,levelNumber,{min,max,current})

    document.querySelector("#clock").insertAdjacentElement('afterend',element)

    var currentDurationNumber = element.querySelector(".max-duration")

    var  minutesText = document.querySelector(".max-duration > span:nth-child(2)")

    var inputRange = element.querySelector('input')

    inputRange.addEventListener('input', function(){
        currentDurationNumber.innerText = `${inputRange.value} Minuto${inputRange.value > 1?'s':''}`
        localStorage.setItem(region, inputRange.value)
        

    })

})