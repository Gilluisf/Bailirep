
var topics = [
    {
        "title": "Área",
        "content": "De acordo com os resultados preliminares do Censo de 2017, a província de Maputo em uma área de 26 058km², e, portanto, uma densidade populacional de 96,2 habitantes por km²."
    },
    {
        "title": "População",
        "content": "A província de Maputo tem 2 507 098 habitantes.\n\nQuando ao género, 53% da população era do sexo feminino e 47% do sexo masculino"
    },
    {
        "title": "Numero de Distrito",
        "content": "A província de Maputo está dividida em 8 distritos, os 7 já existentes quando foi realizado o censo de 2007, mais o distrito da Matola, estabelecido em 2013 para administrar as competências do governo central, e que coincide territorialmente com o município do mesmo nome:\n\n· Boane\n\n· Magude\n\n· Manhiça\n\n·         Marracuene\n\n·         Matola\n\n·         Matutuíne\n\n·         Moamba\n\n·         Namaacha"
    },
    {
        "title": "Distribuição Étnica",
        "content": "De acordo com o censo de 2007, a população de Maputo, com cinco anos de idade ou mais, por língua materna e sexo, estava distribuída da seguinte forma:\n\n·         Português (42,9%), Xichangana (31,5%), Xironga (9,7%), Cichope (3,3%), Xitsua (3,5%), Bitonga (2,8%), outras línguas moçambicanas (4,4%) e outras línguas estrangeiras (1,3%)."
    },
    {
        "title": "Pop. por Distritos",
        "content": "·         Boane: O distrito tem uma superfície de 820  km² e uma população recenseada de 102 457 habitantes, corresponde a uma densidade populacional de 124,9 habitantes/km².\n\n·         Magude: O distrito de Magude tem uma superfície de 6 960  km² e uma população de 54 252 habitantes, com uma densidade populacional de 7,8 habitantes/km².\n\n·         Manhiça: O distrito de Manhiça tem uma superfície de 2 380 km² e uma população de 157 642 habitantes, com uma densidade populacional de 66,2 habitantes/km².\n\n·         Marracuene: O distrito de Marracuene tem uma superfície de 666  km² e uma população recenseada em 2007 de 157 642 habitantes, tendo como resultado uma densidade populacional de 127,6 habitantes/km².\n\n·         Matola: O município tem uma área de 373 km². A sua população é de 1.032.197.\n\n·         Matutuíne:  o distrito tem uma população de 37 239 habitantes e uma área de 5 387 km², com uma densidade populacional de 6,9 habitantes/km².\n\n·         Moamba: O distrito tem uma superfície de 4 628 km² e uma população de 56 746 habitantes, com uma densidade populacional de 12,3 habitantes/km².\n\n·         Namaacha:  o distrito tem 41 954 habitantes e uma área de 2 144  km², com uma densidade populacional de 19,6 habitantes/km²."
    },
    {
        "title": "Culturas Alimentares e Agrícolas",
        "content": "Em relação as culturas de maior produção na província, em termos de área ocupada, destacam-se a mandioca (411.776 ha), o milho (276.961 ha), a mapira (113.535 ha) e os feijões (110.109 ha).\n\nAo longo dos anos, as culturas de rendimento mais significativas foram o algodão, o gergelim e a castanha de Caju."
    },
    {
        "title": "Bacias Hidrográficas",
        "content": "A província tem três bacias hidrográficas importantes, dos rios Maputo, Umbeluzi e Incomáti, que são a continuação das bacias localizadas na África do Sul e Suazilândia."
    },
    {
        "title": "Parques Nacionais",
        "content": " "
    },
    {
        "title": "Reservas Nacionais/Florestais",
        "content": "Reserva Especial de Maputo"
    },
    {
        "title": "Locais de Interesses",
        "content": " "
    },
    {
        "title": "Recursos Minerais e Energia",
        "content": "Na capital do país, Maputo, encontramos o calcário e Água Mineral;"
    },
    {
        "title": "Principais Indústrias",
        "content": "Indústria pesadas:\n\n·         Indústria de produtos minerais não metálicos\n\n·         Indústrias químicas\n\n·         Indústrias metalúrgicas de base\n\n·         Indústrias de materiais de construção\n\n·         Indústria de construção de meios de transporte\n\n·         Indústria de pesca\n\nIndústria Ligeiras:\n\n·         Indústria de açúcar\n\n·         Indústria alimentar e de bebidas\n\n·         Indústria de calçado e outros artigos de vestuário\n\n·         Indústria de descaroçamento de algodão e desfibramento de sisal"
    },
    {
        "title": "Comercio (Importação e Exportação)",
        "content": " "
    },
    {
        "title": "Transporte e Comunicação",
        "content": " "
    }
]