var topics =[
    {
        "title": "Área",
        "content": "Com uma área de 105 008 km², com uma densidade de 48,7 hab./km²."
    },
    {
        "title": "População",
        "content": "Tem uma população de 5 110 787 habitantes."
    },
    {
        "title": "Numero de Distrito",
        "content": "A província da Zambezia está dividida em 22 distritos, quando a realização do censo de 2007, nomeadamente: \n•   Alto Molócuè\n•   Chinde\n•   Derre\n•   Gilé\n•   Gurué\n•   Ile\n•   Inhassunge\n•   Luabo\n•   Lugela\n•   Maganja da Costa\n•   Milange\n•   Mocuba\n•   Mocubela\n•   Molumbo\n•   Mopeia\n•   Morrumbala\n•   Mulevala\n•   Namacurra\n•   Namarroi\n•   Nicoadala\n•   Pebane\n•   Quelimane (Capital).\n"
    },
    {
        "title": "Distribuição Étnica",
        "content": "De acordo com o censo de 2007, a população de Maputo, com cinco anos de idade ou mais, por língua materna e sexo, estava distribuída da seguinte forma:\n•   O elomwe (37,1%);\n•   Echuwabo (23,5%);\n•   Shissena (8%);\n•   Português (9,2%); \n•   outras línguas moçambicanas e  estrangeiras (22,2%).\n"
    },
    {
        "title": "Pop. por Distritos",
        "content": "•   Alto Molocué: De acordo com os resultados finais do Censo de 2017, o distrito tem 356 769 habitantes numa área de 6 338 km², o que resulta numa densidade populacional de 56,3 habitantes por km². \n•   Chinde: Em 2017, o Censo indicou uma população de 85 408 residentes, dos quais 40 731 são homens e 44 677 são mulheres, num distrito cuja área foi reduzida para 3 125  km²,[2], com uma densidade populacional de 27,3 habitantes por km².\n•   Derre: foi criado em 2013, com a elevação a distrito do posto administrativo do Derre que pertencia ao distrito de Morrumbala. Em 2012, o distrito tinha uma população estimada em 85 385 habitantes.\n•   Milange: em 2007, o Censo indicou uma população de 498 635 residentes. Com uma área de 9842  km², a densidade populacional rondava os 50,66 habitantes por km².\n•   Gilé\n•   Gurué\n•   Ile\n•   Inhassunge\n•   Luabo\n•   Lugela\n•   Maganja da Costa\n•   Mocuba\n•   Mocubela\n•   Molumbo\n•   Mopeia\n•   Morrumbala\n•   Mulevala\n•   Namacurra\n•   Namarroi\n•   Nicoadala\n•   Pebane\n•   Quelimane\n"
    },
    {
        "title": "Culturas Alimentares e Agrícolas",
        "content": "Em relação as culturas de maior produção na província, destacam-se o milho, arroz, feijão e tubérculo."
    },
    {
        "title": "Bacias Hidrográficas",
        "content": 'A província tem três bacias hidrográficas importantes, que são: a Bacia do Zambeze e do Licungo;'
    },
    {
        "title": "Parques Nacionais",
        "content": " "
    },
    {
        "title": "Reservas Nacionais/Florestais",
        "content": "Reserva Nacional de Gilé"
    },
    {
        "title": "Locais de Interesses",
        "content": " "
    },
    {
        "title": "Recursos Minerais e Energia",
        "content": "A província de Zambézia contém:\n\n·         Areias pesadas no Distrito de Pebane e Chinde;\n\n·         Pedras preciosas e Tantalite no Distrito do Ile\n\n·         Alto Molócue, água mineral;"
    },
    {
        "title": "Principais Indústrias",
        "content": "Indústria pesadas:\n\n·         Indústria de produtos minerais não metálicos\n\n·         Indústrias de materiais de construção\n\nIndústria Ligeiras:\n\n·         Indústria alimentar e de bebidas\n\n·         Indústria de calçado e outros artigos de vestuário"
    },
    {
        "title": "Comercio (Importação e Exportação)",
        "content": " "
    },
    {
        "title": "Transporte e Comunicação",
        "content": "Aeroporto nacional de Quelimane;\nPorto de Quelimane;\nTerminar rodoviários;\nCaminhos de Ferro de Moçambique;\nPorto de pesca Industrial e porto de pesca artesanal;\n"
    }
]