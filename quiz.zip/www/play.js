const quizContainer = document.getElementById('quiz-container');
const questionElement = document.getElementById('question');

const optionsList = document.getElementById('options');

const optionElements = optionsList.childNodes

const nextButton = document.getElementById('next-btn');

var currentQuestionIndex = 0;

var score = 0;

//alert(localStorage.soundEnabled?1:0)

var musicAudio = new Audio('music/music.mp3')
musicAudio.volume = 0
musicAudio.loop = true
musicAudio.play()

setInterval(function () {
    var currentVolume = Number(localStorage.MUSIC_VOLUME || 0) / 100
	
    if (musicAudio.volume != currentVolume) {
        musicAudio.volume = currentVolume
    } 
},1)

const quizQuestions2 = quizQuestions

quizQuestions = shuffleArray(quizQuestions).map(array => {
    
    let correctOption = array.options[array.correctOptionIndex]
    array.options = shuffleArray(array.options)
    array.correctOptionIndex = Object.keys(array.options).find(key=>array.options[key] == correctOption)
    
    return array
})

quizQuestions = shuffleArray(quizQuestions)

quizQuestions = quizQuestions.filter(elem => !getHistory().includes(elem.question))

while (quizQuestions.length < 20) {
     var question = quizQuestions2.find(elem => !quizQuestions.includes(elem))
        
    quizQuestions.push(question)
        
}   



while (quizQuestions.length != 20) {
    quizQuestions.pop()
}

function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Function to load a question

function loadQuestion() {

    const currentQuestion = quizQuestions[currentQuestionIndex];

    questionElement.textContent = currentQuestion.question.replace(/\w+\.png/i,'');

    var baseImage = currentQuestion.question.match(/\w+\.png/i)

    var imageElement = document.querySelector("#quiz-container img")
    imageElement.src = baseImage?`img/questions/${baseImage.toString()}`:''
    
    questionElement.style.paddding = baseImage?"padding: 4px 4px":""

    // Clear previous options

    optionsList.innerHTML = '';

    // Create new options

    currentQuestion.options.forEach((option, index) => {

        const optionElement = document.createElement('button');
        optionElement.style.fontSize = baseImage?'16px':'20px'
        optionElement.textContent = option

        optionElement.classList.add('button');
        optionElement.classList.add('large')
        optionElement.onclick= () => selectAnswer(index);

        optionsList.appendChild(optionElement);

    });

    showRank()

}

function showRank () {
    document.querySelector("#question-rank > button").innerHTML=`${currentQuestionIndex+1}/20`
}

function addToHistory(question){

    var questions = getHistory()
    if (questions.includes(question)) {

        return 0
    }
    questions.push(question)
    localStorage.setItem('questions', JSON.stringify(questions))
}

function getHistory(){

   return localStorage.questions?JSON.parse(localStorage.questions):[]
}
// Function to handle answer selection
var correctAudio = new Audio('music/correct-answer.mp3')
var wrongAudio = new Audio('music/wrong-answer.mp3')
function selectAnswer(selectedOptionIndex) {
    //debugger
    const currentQuestion = quizQuestions[currentQuestionIndex];

    const correctOptionIndex = currentQuestion.correctOptionIndex;

    // Check if the selected option is correct
    addToHistory(currentQuestion.question)

    if (selectedOptionIndex == correctOptionIndex) {

        //optionElements[selectedOptionIndex].style.backgroundColor = 'green';
        //console.log('accertou')
        
        //correct.playbackRate=3
        correctAudio.play()
        score++;

    } else {
        //console.log('errou')
       
       //wrong.playbackRate=3
       wrongAudio.play()

        optionElements[selectedOptionIndex].style.backgroundImage='none'
        optionElements[selectedOptionIndex].style.backgroundColor = 'red';

        

    }
    optionElements[correctOptionIndex].style.backgroundImage='none'
    optionElements[correctOptionIndex].style.backgroundColor = 'green';
    // Disable option selection after answering

    //console.log(optionElements[correctOptionIndex],optionElements[selectedOptionIndex])
    Array.from(optionElements).forEach((option, index) => {

        option.onclick =null

        //option.style.pointerEvents = 'none';

    });

    showScore()

}

function showScore (argument) {
    document.querySelector("#points-number > span:nth-child(2)").innerHTML=score
}
function Tag(a,b){
    //alert([a,b].join(""))
    return document[`querySelector${b?'All':''}`](a);
    //return  !b? document.querySelector(a) : document.querySelectorAll(a)
    
}

function showFadeEffect(){
	quizContainer.style.opacity="0"
	setTimeout(() => quizContainer.style.opacity="1", 450)
}
// Function to handle next question

function nextQuestion() {

    
    // Increment question index

    currentQuestionIndex++;

    // Check if quiz is completed

    if (currentQuestionIndex === quizQuestions.length) {

        finishQuiz();

    } else {

        // Load next question

        loadQuestion();

        // Reset option backgrounds

        Array.from(optionElements).forEach((option) => {

            option.style.backgroundColor = '';

        });

    }

}

// Function to finish the quiz
var gameFinished = false
function finishQuiz() {
	gameFinished = true
    // Display quiz results

    quizContainer.innerHTML = `
        <button class="button large" onclick="location.reload()">
            Moçambique
            <span class="badge">❤️</span>
        </button>

        <button class="button large">
            África
            <span class="badge">🔒</span>
        </button>

        <button class="button large">
            Mundo
            <span class="badge">🔒</span>
        </button>

        <button class="button small button-3d" style="background-image: linear-gradient(green, #4caf50); margin-top:70px; box-shadow:none; display:${score == 20?'auto':'none'}">Nível 02</button>
        `;
    
    /*var clapsAudio = Tag('#claps')
   
    if (score == 20) {
        clapsAudio.play()
    } */
    
    musicAudio.pause()

}

// Load the first question

loadQuestion();

// Event listener for the next question button

nextButton.addEventListener('click',()=>{
	if(gameFinished) return;
    showFadeEffect()
    setTimeout(nextQuestion, 400)
    
});

const minutes = Number(localStorage['Moçambique']) || 1
var timeLeft = 1000 * 60 * minutes
const secondsElement = document.querySelector("#time-left > button")

var timer = setInterval(function () {
    timeLeft = timeLeft-1000
    var date = new Date(timeLeft)
    secondsElement.innerHTML = `${date.getMinutes()}:${date.getSeconds()}`.replace(/\d{1,}/g,function(text){
        //console.log(text)
        return text.length == 2?text:'0'+text
    })
    
	if(gameFinished){
		clearInterval(timer)
		
	}
	
    if (timeLeft == 0) {

        clearInterval(timer)
        currentQuestionIndex=19
        nextQuestion()
        console.log('esgotado')
    }
}, 1000)