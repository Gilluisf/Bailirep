var quizQuestions = [
  {
    "question": "Quantas capitais tem o país?",
    "options": ["11", "10", "13", "14"],
    "correctOptionIndex": 0
  },
  {
    "question": "Qual é a província mais populosa de Moçambique?",
    "options": ["Nampula", "Zambézia", "Cabo Delegado", "Inhambane"],
    "correctOptionIndex": 0
  },
  {
    "question": "Qual é a província mais extensa de Moçambique?",
    "options": ["Cabo Delgado", "Nampula", "Niassa", "Tete"],
    "correctOptionIndex": 0
  },
  {
    "question": "Qual a Província com mais distritos?",
    "options": ["Nampula", "Quelimane", "Tete", "Cabo Delgado"],
    "correctOptionIndex": 0
  },
  {
    "question": "Qual desses grupos faz parte dos símbolos de Moçambique?",
    "options": ["Bandeira e Emblema", "Emblema e Hino", "Hino e Bandeira", "Bandeira, Emblema e Hino"],
    "correctOptionIndex": 0
  },
  {
    "question": "O norte de Moçambique é composto por:",
    "options": ["Nampula, Cabo delgado e Niassa", "Tete, Nampula e Niassa", "Zambézia, Nampula e Cabo Delgado", "Cabo delgado, Zambézia e Niassa"],
    "correctOptionIndex": 0
  },
  {
    "question": "A Língua mais falada no Pais é?",
    "options": ["Elomwe", "Emakua", "Changana", "Sena"],
    "correctOptionIndex": 0
  },
  {
    "question": "Moçambique se situa no:",
    "options": ["Sudeste de África", "Nordeste de África", "Oeste de África", "Leste de África"],
    "correctOptionIndex": 0
  },
  {
    "question": "O maior lago de Moçambique é?",
    "options": ["Lago Niassa", "Lago Victoria", "Lago do Zambeze", "Lago do Nilo"],
    "correctOptionIndex": 0
  },
  {
    "question": "O maior produtor de coco no país é?",
    "options": ["Zambézia", "Inhambane", "Gaza", "Cabo Delgado"],
    "correctOptionIndex": 0
  },
  {
    "question": "A Maior Bacia Hidrográfica no país é?",
    "options": ["Bacia do Rovuma", "Bacia do Zambeze", "Bacia do Save", "Nenhuma"],
    "correctOptionIndex": 0
  },
  {
    "question": "Moçambique contem:",
    "options": ["8 parques", "9 parques", "7 parques", "6 parques"],
    "correctOptionIndex": 0
  },
  {
    "question": "O maior parque de Moçambique é?",
    "options": ["Parque de Limpopo em Gaza", "Parque de Banhine em Gaza", "Parque das Quirimbas em Cabo Delgado", "Parque de Maputo em Maputo"],
    "correctOptionIndex": 0
  },
  {
    "question": "A maior reserva Nacional é?",
    "options": ["Reserva de Pomone em Inhambane", "Reserva de Niassa, em Niassa", "Reserva de Marromeu, em Sofala, no sul do rio Zambeze", "Reserva de Gilé, na Zambézia"],
    "correctOptionIndex": 0
  },
  /*{
    "question": "A ilha pertencente a SADC é?",
    "options": ["Madagáscar e Seicheles", "Seicheles e Cabo Verde", "Cabo Verde e Madagáscar", "Todas Ilhas"],
    "correctOptionIndex": 0
  },
  {
    "question": "O mundo contém:",
    "options": ["6 Continentes", "5 Continentes", "7 Continentes", "4 Continentes"],
    "correctOptionIndex": 0
  },
  {
    "question": "O maior continente do mundo é?",
    "options": ["Ásia", "África", "América do Norte", "América do Sul"],
    "correctOptionIndex": 0
  },
  {
    "question": "O maior país do mundo",
    "options": ["Rússia", "China", "Estados Unidos", "Brasil"],
    "correctOptionIndex": 0
  },
  {
    "question": "O país mais populoso do mundo",
    "options": ["China", "Rússia", "Estados Unidos", "Brasil"],
    "correctOptionIndex": 0
  },*/
  {
    "question": "Qual é a capital de Moçambique?",
    "options": ["Maputo", "Nampula", "Beira", "Quelimane"],
    "correctOptionIndex": 0
  },
  {
    "question": "Quem é o presidente de Moçambique?",
    "options": ["Filipe Nyusi", "Armando Guebuza", "Samora Machel", "Joaquim Chissano"],
    "correctOptionIndex": 0
  },
  {
    "question": "Qual é a moeda oficial de Moçambique?",
    "options": ["Metical", "Kwacha", "Rand", "Pula"],
    "correctOptionIndex": 0
  },
  {
    "question": "Qual é a principal atividade econômica de Moçambique?",
    "options": ["Agricultura", "Pesca", "Mineração", "Turismo"],
    "correctOptionIndex": 0
  },
  {
    "question": "Qual é o prato típico mais famoso de Moçambique?",
    "options": ["Matapa", "Piri-Piri", "Chamussas", "Frango à Cafrial"],
    "correctOptionIndex": 0
  },
  {
    question: "Qual destas danças tradicionais  está representada na imagem? marrabenta.png",
    options: ["Marrabenta", "Makwaya", "Tufo", "Mapiko"],
    correctOptionIndex: 0,
  },
  {
    question: "A que grupo étnico pertence esta máscara tradicional? makonde.png",
    options: ["Makonde", "Chope", "Tsonga", "Macua"],
    correctOptionIndex: 0,
  },
  {
    question: "Que instrumento musical tradicional é este? timbila.png",
    options: ["Timbila", "Marimba", "Mbira", "Xitende"],
    correctOptionIndex: 0,
  },
  {
  question: "A capital da Zambézia é:",
  options: ["Quelimane", "Milange", "Mocuba", "Pemba"],
  correctOptionIndex: 0
  },
  {
  question: "A capital de Maputo Província é:",
  options: ["Matola", "Xai-xai", "Maputo", "Marracuene"],
  correctOptionIndex: 2
  },
  {
  question: "A capital de Inhambane é:",
  options: ["Inhambane", "Nampula", "Chimoio", "Lichinga"],
  correctOptionIndex: 0
  },
  {
  question: "A capital da Gaza é:",
  options: ["Xai-xai", "Gaza", "Manica", "Tete"],
  correctOptionIndex: 1
  },
  {
  question: "A capital de Sofala é:",
  options: ["Beira", "Quelimane", "Lichinga", "Chimoio"],
  correctOptionIndex: 0
  },
  {
  question: "A capital da Manica é:",
  options: ["Chimoio", "Manica", "Lichinga", "Nampula"],
  correctOptionIndex: 1
  },
  {
  question: "A capital da Tete é:",
  options: ["Tete", "Moatize", "Nampula", "Pemba"],
  correctOptionIndex: 0
  },
  {
  question: "A capital de Nampula é:",
  options: ["Nampula", "Moma", "Nacala", "Pemba"],
  correctOptionIndex: 0
  },
  {
  question: "A capital da Cabo Delgado é:",
  options: ["Pemba", "Lichinga", "Chimoio", "Xai-xai"],
  correctOptionIndex: 0
  },
  {
  question: "A capital de Niassa é:",
  options: ["Lichinga", "Pemba", "Quelimane", "Tete"],
  correctOptionIndex: 0
  },
  {
  question: "O rio Ligonha está entre:",
  options: ["Zambézia e Nampula", "Tete e Nampula", "Nampula e Niassa", "Niassa e Zambézia"],
  correctOptionIndex: 0
  },
  {
  question: "O rio Pungue está na Província de:",
  options: ["Sofala", "Inhambane", "Manica", "Tete"],
  correctOptionIndex: 0
  },
  {
  question: "Moçambique pertence ao continente:",
  options: ["Africano", "Europeu", "Americano", "Asiático"],
  correctOptionIndex: 0
  },
  {
  question: "O aeroporto internacional está em:",
  options: ["Maputo, Beira, Nampula e Nacala", "Baia de Pemba, Maputo, Beira e Nampula", "Inhambane, Pemba, Maputo e Beira", "Quelimane, Vilanculos, Xai-xai e Tete"],
  correctOptionIndex: 1
  },
  {
  question: "O distrito de Zavala pertence à:",
  options: ["Província de Inhambane", "Província de Gaza", "Província de Niassa", "Província de Tete"],
  correctOptionIndex: 0
  },
  {
  question: "O maior produtor de amendoim é:",
  options: ["Niassa", "Cabo Delgado", "Zambézia", "Tete"],
  correctOptionIndex: 3
  },
  {
  question: "O distrito que faz parte da costa Moçambicana é:",
  options: ["Nacala", "Mocuba", "Moatize", "Distrito de Lago"],
  correctOptionIndex: 3
  },
  {
  question: "A Ilha de Moçambique pertence à Província de:",
  options: ["Nampula", "Cabo Delegado", "Niassa", "Pemba"],
  correctOptionIndex: 0
  },
  {
  question: "O país está dividido em:",
  options: ["3 regiões", "2 regiões", "4 regiões", "5 regiões"],
  correctOptionIndex: 0
  },
  {
  question: "As regiões do nosso país são:",
  options: ["Norte, Centro e Sul", "Norte, Sul, Este e Oeste", "Nordeste, Sudoeste e Centro", "Central, Sul e Leste"],
  correctOptionIndex: 0
  },
  {
  question: "A maior produção de mineiros está em:",
  options: ["Tete", "Zambézia", "Nampula", "Cabo Delgado"],
  correctOptionIndex: 0
  },
  {
  question: "A capital industrial de Moçambique é:",
  options: ["Nampula", "Maputo", "Tete", "Beira"],
  correctOptionIndex: 0
  },
  {
  question: "A maior produção de gado bovino está em:",
  options: ["Gaza", "Inhambane", "Maputo", "Tete"],
  correctOptionIndex: 0
  },
  {
  question: "A província com mais índice turístico:",
  options: ["Inhambane", "Pemba", "Gaza", "Cabo Delgado"],
  correctOptionIndex: 0
  }
  
]
