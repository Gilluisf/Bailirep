var htmlFooterCode = `
<!--div id="footer"-->
    		<div class="button-captioned" onclick="history.back()">
					<img src="img/back.png" class="icon-button" style="margin:0;padding:0">
					<button class="button small button-3d">Voltar</button>
			</div>

    		<div class="button-captioned"  onclick="location.assign('index.html')">
					<img src="img/menu.png" class="icon-button" style="margin:0;padding:0">
					<button class="button small button-3d">Menu</button>
			</div>

    		<div class="button-captioned" onclick="settingsScreen.open()">
					<img src="img/settings.png" class="icon-button" style="margin:0;padding:0">
					<button class="button small button-3d">Definições</button>
			</div>
    	<!--/div-->
`
document.querySelector('#footer').innerHTML = htmlFooterCode
